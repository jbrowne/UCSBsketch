import clr

clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')
clr.AddReference('WPFFrameworkElementExtension.dll')

from System.Windows.Markup import XamlReader
from System.Windows import Application
from System.IO import FileStream, FileMode
from System.Windows.Controls import InkCanvas
from System.Windows.Media import Brushes

import GeomUtils    #Import GeomUtils first.  Just do it.  Lest Point won't load when being loaded through Board.  Still can't figure out root cause, guessing something with Circular dependencies?

from Stroke import Stroke
from Point import Point
from Board import BoardSingleton
from SketchGUI import _SketchGUI
from SketchGUI import SketchGUISingleton

########################################

class _WpfSketchGUI(_SketchGUI):
    
    Singleton = None
    
    def __init__(self, wpfCanvas):
        self.Board = BoardSingleton(reset = True)
        self.Canvas = wpfCanvas
        self.Singleton = self
        _WpfSketchGUI.Singleton = self
    
    def InkCanvas_StrokeCollected( self, sender, e ):   #e is a InkCanvasStrokeCollectedEventArgs 
    
        pointList = []
        
        #Transform the Canvas's Points into our Points
        for stylusPoint in e.Stroke.StylusPoints:
            pointList.append( Point( stylusPoint.X, stylusPoint.Y ) )
        
        newStroke = Stroke( pointList )
        
        self.Board.AddStroke( newStroke )
        
        SketchGUISingleton().drawCircle( 2, 2, 2 )
#        _WpfSketchGUI.Singleton.drawCircle( 2,2,2 )
        
        #sender is the WPF InkCanvas
        #sender.Background = Brushes.LightGreen
        
        
    def drawCircle(self, x, y, radius=1, color="#000000", fill="", width=1.0):
        "Draw a circle on the canvas at (x,y) with radius rad. Color should be 24 bit RGB string #RRGGBB. Empty string is transparent"
        self.Canvas.Background = Brushes.LightGreen
        #(x-radius,y-radius,x+radius,y+radius)
        
         
    def drawLine(self, x1, y1, x2, y2, width=2, color="#000000"):
         "Draw a line on the canvas from (x1,y1) to (x2,y2). Color should be 24 bit RGB string #RRGGBB"
         self.Canvas.Background = Brushes.LightGreen
         
    def drawText (self, x, y, InText="", size=10, color="#000000"):
        "Draw some text (InText) on the canvas at (x,y). Color as defined by 24 bit RGB string #RRGGBB"
        self.Canvas.Background = Brushes.LightGreen
        
        
def WpfSketchGUISingleton():
    if _WpfSketchGUI.Singleton == None:
       LoadApp()
       
    return _WpfSketchGUI.Singleton
#TODO: Stroke Removal.


########################################

def LoadApp():
    app = Application()

    #Load the XAML.
    xamlWindow = XamlReader.Load(FileStream('SketchCade.xaml', FileMode.Open))	#Window object as the root.

    #wsg = _WpfSketchGUI( xamlWindow.InkCanvas )
    #_WpfSketchGUI.Singleton = wsg
    
    _WpfSketchGUI.Singleton = _WpfSketchGUI( xamlWindow.InkCanvas )

    #Bind the Event Handler
    xamlWindow.InkCanvas.StrokeCollected += _WpfSketchGUI.Singleton.InkCanvas_StrokeCollected
    
    
    app.Run(xamlWindow)

########################################

if __name__ == "__main__":
    LoadApp()
    