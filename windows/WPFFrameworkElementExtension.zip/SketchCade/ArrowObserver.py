"""
filename: ArrowObserver.py

description:
   This module implements 2 classes, ArrowAnnotation (which is applied to any 
   annotableObjects to describe as an arrow), and ArrowMarker (which watches
   for strokes that looks like arrows and adds the arrow annotation)

Doctest Examples:

>>> c = ArrowMarker()

example of something not a arrow
>>> linepoints = [Point(x,2*x) for x in range(1,20)] 
>>> c.onStrokeAdded(Stroke(linepoints))

"""

#-------------------------------------

import math
import Logger
import GeomUtils
import SketchGUI
from Point import Point
from Stroke import Stroke
from Board import BoardObserver, BoardSingleton
from Annotation import Annotation, AnnotatableObject

logger = Logger.getLogger('ArrowObserver', Logger.WARN )

#-------------------------------------

class ArrowAnnotation( Annotation ):
    def __init__(self, tip, tail, linearity=0):
        Annotation.__init__(self)
        self.tip = tip  # Point
        self.tail = tail  # Point
        self.linearity = linearity

#-------------------------------------

# FIXME: first go -- only single stroke arrows

class ArrowMarker( BoardObserver ):

    def __init__(self, circularity_threshold=0.85):
        BoardSingleton().AddBoardObserver( self )
        BoardSingleton().RegisterForStroke( self )
	self.threshold = circularity_threshold;

    def onStrokeAdded( self, stroke ):
        "Watches for Strokes that look like an arrow to Annotate"

        logger.debug("stroke len %d", stroke.length() )
        if len(stroke.Points) < 10:
            return # too small to be arrow

        norm_len = stroke.length()
        points = GeomUtils.strokeNormalizeSpacing( stroke, norm_len ).Points

        points.reverse() # start from end
        # find the first 90 degree turn in the stroke
        orilist = GeomUtils.strokeLineSegOrientations( Stroke(points) )
        logger.debug("stroke ori %s", str(orilist) )
        for i,ori in enumerate(orilist):
            if GeomUtils.angleDiff(ori,0)>90: break  # found the first turn at index i
        first_corner = i
        # now we know the scale of the arrow head if there is one
        # if the first corner is more than 1/4 of the way from the end of the stroke
        if first_corner > norm_len/5:
            return # scale is wrong for an arrowhead        

        tail = stroke.Points[0] # first of the original points
        tip = points[i] # reverse point

        # create a list of the monoticity of all substrokes from the first corner to some dist after
        m_list = [ GeomUtils.strokeMonotonicity(Stroke(points[first_corner:x])) for x in range(first_corner+2,first_corner*3) ]
        m_min = min(m_list) 
        logger.debug("stroke mon (%f)", m_min )
        if m_min>0.65:
            return # too monotonic after the first corner, need to double back

        anno = ArrowAnnotation( tip, tail )
        BoardSingleton().AnnotateStrokes( [stroke],  anno)

    def onStrokeRemoved(self, stroke):
	"When a stroke is removed, remove arrow annotation if found"
    	for anno in stroke.findAnnotations(ArrowAnnotation, True):
            BoardSingleton().RemoveAnnotation(anno)

#-------------------------------------

class ArrowVisualizer( BoardObserver ):
    "Watches for Arrow annotations, draws them"
    def __init__(self):
        BoardSingleton().AddBoardObserver( self )
        BoardSingleton().RegisterForAnnotation( ArrowAnnotation, self )
        self.annotation_list = []

    def onAnnotationAdded( self, strokes, annotation ):
        "Watches for annotations of Arrows and prints out the Underlying Data" 
        self.annotation_list.append(annotation)

    def onAnnotationRemoved(self, annotation):
        "Watches for annotations to be removed" 
        self.annotation_list.remove(annotation)

    def drawMyself( self ):
        for a in self.annotation_list:
            SketchGUI.drawCircle( a.tail.X, a.tail.Y, color="#aaddff", width=2.0, radius=4)
            SketchGUI.drawCircle( a.tip.X, a.tip.Y, color="#aaddff", width=2.0, radius=4)
            #SketchGUI.drawLine( a.tail.X, a.tail.Y, a.tip.X, a.tip.Y, color="#88ccff", width=2.0)

#-------------------------------------
# if executed by itself, run all the doc tests

if __name__ == "__main__":
    Logger.setDoctest(logger) 
    import doctest
    doctest.testmod()
