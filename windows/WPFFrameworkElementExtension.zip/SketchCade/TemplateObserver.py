"""
filename: TemplateObserver.py

description:


Doctest Examples:

"""

#-------------------------------------
import Point
import Stroke
import GeomUtils
import SketchGUI
from Annotation import Annotation
from Board import BoardObserver, BoardSingleton


import Logger
logger = Logger.getLogger('TemplateObserver', Logger.DEBUG )

#-------------------------------------

class TemplateAnnotation(Annotation):
    "Annotation for strokes matching templates. Fields: name - the template's tag/name, template - the list of points making up the template"
    def __init__(self, tag, template):
        Annotation.__init__(self)
        self.name = tag
        self.template = template

#-------------------------------------

class TemplateMarker( BoardObserver ):
    "Compares all strokes with templates and annotates strokes with any template within some threshold."
    def __init__(self, filename, resampleSize = 64):
        
        BoardSingleton().AddBoardObserver( self )
        BoardSingleton().RegisterForStroke( self )

        self.loadTemplates(filename = filename)
        self._resampleSize = resampleSize

    def loadTemplates(self, filename):
        "Load templates from filename into self._templates"
        logger.debug("Loading templates: %s" % filename)
        try:
           fp = open(filename, "r")
        except:
           return
        
        self._templates = {}
        current_template = None 
        for line in fp.readlines():
           fields = line.split()
           if line.startswith("#TEMPLATE"):
               assert len(fields) == 2
               current_template = fields[1]
               self._templates[current_template] = []
           elif line.startswith("#END"):
               assert len(fields) == 2
               template_name = fields[1]
               assert current_template == template_name
               current_template = None 
               logger.debug('   "%s" loaded' % template_name)
           else:
               assert len(fields) == 2
               x = float(fields[0])
               y = float(fields[1])
               assert current_template is not None
               self._templates[current_template].append(Point.Point(x, y))
        logger.debug("Loaded %s templates" % len(self._templates))
        return self._templates

    def onStrokeAdded( self, stroke ):
        "Compare this stroke to all templates, and annotate those matching within some threshold."
        logger.debug("Scoring templates")
        for name, template in self._templates.items():
            score = scoreStroke(stroke, template, self._resampleSize)
            logger.debug("   '%s' ... %s" % (name, score))
            if score < 0.2:
                anno = TemplateAnnotation(name, template)
                BoardSingleton().AnnotateStrokes( [stroke], anno )


    def onStrokeRemoved(self, stroke):
	"When a stroke is removed, remove circle annotation if found"
    	for anno in stroke.findAnnotations(TemplateAnnotation, True):
            BoardSingleton().RemoveAnnotation(anno)

#-------------------------------------

def scoreStroke(stroke, template, sample_size):
    sNorm = GeomUtils.strokeNormalizeSpacing(stroke, sample_size)
    centr = GeomUtils.centroid(sNorm.Points)
    point_vect = []
    templ_vect = []
    for q in template:
       templ_vect.append(q.X)
       templ_vect.append(q.Y)
    for p in sNorm.Points:
       point_vect.append(p.X - centr.X)
       point_vect.append(p.Y - centr.Y)
    angularDist = GeomUtils.vectorDistance(point_vect, templ_vect)
    return angularDist

#-------------------------------------

class TemplateVisualizer( BoardObserver ):
    "Watches for Template annotations, draws them"
    def __init__(self):
        BoardSingleton().AddBoardObserver( self )
        BoardSingleton().RegisterForAnnotation( TemplateAnnotation, self )
        self.annotation_list = []

    def onAnnotationAdded( self, strokes, annotation ):
        "Watches for annotations of Templates and draws the idealized template" 
        logger.debug( "A stroke was annotated as matching template: %s" % annotation.name )
        self.annotation_list.append(annotation)

    def onAnnotationRemoved(self, annotation):
        "Watches for annotations to be removed" 
        logger.debug( "A template matching %s was removed" % (annotation.name))
        self.annotation_list.remove(annotation)

    def drawMyself( self ):
	for a in self.annotation_list:
            center = GeomUtils.centroid(a.Strokes[0].Points) #Ugly hack to get the center of the annotation!
            templ_stroke = Stroke.Stroke(a.template)
            templ_stroke = templ_stroke.translate(center.X, center.Y)

            SketchGUI.drawStroke(templ_stroke, color="#F050F0")

#-------------------------------------
# if executed by itself, run all the doc tests

if __name__ == "__main__":
    Logger.setDoctest(logger) 
    import doctest
    doctest.testmod()
