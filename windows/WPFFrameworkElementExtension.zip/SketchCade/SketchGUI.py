#!/usr/bin/python
"""
filename: SketchGUI.py

Description:
   This class should control all interface matters. It must export:
       SketchGUISingleton
       SketchGUI (Class)
          drawLine
          drawCircle
          drawText
   All other functions and interface behavior is up to the GUI designer.
   This implementation listens for MouseDown events and builds strokes to hand off
      to the board system. Upon any event, Redraw is called globally to fetch all 
      board paint objects and display them.
"""

from Point import Point
#from Stroke import Stroke
#from Board import BoardSingleton
from SketchSystem import initialize, standAloneMain

class _SketchGUI(object):
    """The base GUI class. 
    Class must implement drawText, drawLine and drawCircle. X-Y origin is bottom-left corner.
    Aside from these restrictions, interface options (reset board, etc) are up to the GUI programmer."""
    Singleton = None
    def __init__(self):
        pass

    def drawCircle(self, x, y, radius=1, color="#000000", fill="", width=1.0):
        "Draw a circle on the canvas at (x,y) with radius rad. Color should be 24 bit RGB string #RRGGBB. Empty string is transparent"
        pass
        #(x-radius,y-radius,x+radius,y+radius)
        
        
         
    def drawLine(self, x1, y1, x2, y2, width=2, color="#000000"):
         "Draw a line on the canvas from (x1,y1) to (x2,y2). Color should be 24 bit RGB string #RRGGBB"
         pass
         
    def drawText (self, x, y, InText="", size=10, color="#000000"):
        "Draw some text (InText) on the canvas at (x,y). Color as defined by 24 bit RGB string #RRGGBB"
        pass

def SketchGUISingleton():
    "Returns the GUI instance we're currently working with."
    import WpfSketchGUI as GuiInstance
    
    
    if _SketchGUI.Singleton == None:
       _SketchGUI.Singleton = GuiInstance._WpfSketchGUI.Singleton   #_SketchGUI()
       
    return _SketchGUI.Singleton
    
    



def drawCircle (x, y, radius=1, color="#000000", fill="", width=1.0):
    s = SketchGUISingleton()
    s.drawCircle(x,y,radius=radius,  color=color, fill=fill, width=width)

def drawText (x, y, InText="", size=10, color="#000000"):
    s = SketchGUISingleton()
    s.drawText(x,y,InText=InText, size = size, color=color)

def drawLine(x1, y1, x2, y2, width=2, color="#000000"):
    s = SketchGUISingleton()
    s.drawLine(x1,y1,x2,y2, width=width, color=color)
    
def drawBox(topleft, bottomright, color="#000000", width=2):
    s = SketchGUISingleton()
    s.drawLine(topleft.X, topleft.Y, bottomright.X, topleft.Y, color=color, width=width)
    s.drawLine(bottomright.X, topleft.Y, bottomright.X, bottomright.Y, color=color, width=width)
    s.drawLine(bottomright.X, bottomright.Y, topleft.X, bottomright.Y, color=color, width=width)
    s.drawLine(topleft.X, bottomright.Y, topleft.X, topleft.Y, color=color, width=width)
    
def drawStroke(stroke, width = 2, color="#000000"):
    s = SketchGUISingleton()
    prev_p = None
    for next_p in stroke.Points:
        if prev_p is not None:
            s.drawLine(prev_p.X, prev_p.Y, next_p.X, next_p.Y, width=width, color=color)
        prev_p = next_p


